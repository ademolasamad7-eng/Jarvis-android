JARVIS 6 — ANDROID / IRON MAN MODE

This is the native Android wrapper for the fixed JV3/JV4 interface.

WHAT IT DOES
- Keeps the existing JARVIS UI in a WebView.
- Native Android microphone service runs as a foreground microphone service.
- Repeated speech recognition continues while the app is minimized/screen is off, subject to Android/device restrictions.
- It looks for the phrase “Hey JARVIS”; when detected, the spoken command is delivered to the JARVIS UI.
- Native Android Text-to-Speech speaks JARVIS replies.
- The AI brain remains server-side so the API key is not stored in the APK.

IMPORTANT
1. In MainActivity.java change SERVER from http://YOUR-JARVIS-SERVER:3000 to your deployed HTTPS JARVIS server URL.
2. Build the Android project in Android Studio.
3. Install the APK and grant microphone + notification permissions.
4. Open JARVIS once and leave its voice service enabled. Android may show an ongoing notification; this is required for a microphone foreground service.
5. Battery optimization should be disabled for JARVIS on phones that aggressively stop background apps.

LIMITATION
This is not a guaranteed hardware-level hotword engine. Android and individual phone vendors can restrict continuous microphone recognition. A true system-level “Hey JARVIS” wake word requires supported Android voice-assistant/hotword APIs or a dedicated wake-word engine.

AI SERVER
The included server.js is the backend. Keep OPENAI_API_KEY only on that server. Do not put it into the Android app.

NO COMPUTER OPTION
The included .github/workflows/android.yml can build the APK in GitHub Actions after the project is uploaded to a GitHub repository. This avoids needing Android Studio on the phone.
