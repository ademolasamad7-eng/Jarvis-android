package com.dspark.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;
import android.widget.Toast;

public class MainActivity extends Activity {
    WebView web;
    static MainActivity instance;
    final String SERVER = "http://YOUR-JARVIS-SERVER:3000";

    @Override public void onCreate(Bundle b){ super.onCreate(b); instance=this;
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS},20);
        web=new WebView(this); web.setBackgroundColor(0xff05070d); WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(),"AndroidJarvis");
        web.loadUrl("file:///android_asset/index.html"); setContentView(web);
        startVoiceService();
    }
    void startVoiceService(){ try{ Intent i=new Intent(this,JarvisVoiceService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); }catch(Exception e){} }
    public void deliver(String text){ if(web==null)return; runOnUiThread(()->web.evaluateJavascript("window.jarvisNativeTranscript("+JSONObjectQuote(text)+")",null)); }
    String JSONObjectQuote(String x){ return "\""+x.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","")+"\""; }
    public class Bridge {
        @JavascriptInterface public void startListening(){ JarvisVoiceService.requestListen=true; startVoiceService(); }
        @JavascriptInterface public void stopListening(){ JarvisVoiceService.requestStop=true; }
        @JavascriptInterface public void speak(String text){ JarvisVoiceService.speakText(text); }
        @JavascriptInterface public String getServer(){ return SERVER; }
    }
}
