package com.dspark.jarvis;

import android.app.*; import android.content.*; import android.content.pm.ServiceInfo; import android.os.*; import android.speech.*; import android.speech.tts.*; import java.util.*;

public class JarvisVoiceService extends Service {
    static volatile boolean requestListen=false, requestStop=false; static JarvisVoiceService self; SpeechRecognizer sr; Intent intent; TextToSpeech tts; Handler h=new Handler(Looper.getMainLooper());
    final String CH="jarvis_voice";
    @Override public void onCreate(){ super.onCreate(); self=this; createChannel();
        Notification n=new Notification.Builder(this,CH).setContentTitle("JARVIS is active").setContentText("Listening for JARVIS voice commands").setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=29) startForeground(7,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE); else startForeground(7,n);
        tts=new TextToSpeech(this,status->{ if(status==TextToSpeech.SUCCESS){tts.setLanguage(Locale.US); tts.setSpeechRate(.98f);}});
        if(SpeechRecognizer.isRecognitionAvailable(this)) setup();
        h.postDelayed(loop,1000);
    }
    void setup(){ sr=SpeechRecognizer.createSpeechRecognizer(this); sr.setRecognitionListener(new RecognitionListener(){
        public void onReadyForSpeech(Bundle p){} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){ schedule(); }
        public void onError(int e){ schedule(); }
        public void onResults(Bundle b){ ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a!=null&&!a.isEmpty()){ String s=a.get(0); if(s.toLowerCase(Locale.US).contains("hey jarvis")){ int k=s.toLowerCase(Locale.US).indexOf("hey jarvis"); s=s.substring(k+10).trim(); } if(!s.isEmpty()&&MainActivity.instance!=null) MainActivity.instance.deliver(s); } schedule(); }
        public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle p){}
    }); intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.US.toLanguageTag()); intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);
    }
    void schedule(){ h.removeCallbacks(loop); h.postDelayed(loop,500); }
    Runnable loop=()->{ if(requestStop){requestStop=false; return;} startRec(); };
    void startRec(){ if(sr==null)return; try{sr.startListening(intent);}catch(Exception e){schedule();} }
    static void speakText(String s){ if(self!=null&&self.tts!=null) self.tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarvis"); }
    void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationManager m=getSystemService(NotificationManager.class); m.createNotificationChannel(new NotificationChannel(CH,"JARVIS Voice",NotificationManager.IMPORTANCE_LOW));}}
    @Override public int onStartCommand(Intent i,int f,int id){ if(requestListen){requestListen=false; schedule();} return START_STICKY; }
    @Override public void onDestroy(){ if(sr!=null)sr.destroy(); if(tts!=null)tts.shutdown(); super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
