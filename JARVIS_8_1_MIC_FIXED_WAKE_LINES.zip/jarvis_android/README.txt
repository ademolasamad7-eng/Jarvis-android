JARVIS V5 — IRON MAN BRAIN BUILD

This build preserves the JV3/JV4 visual interface and adds a real server-side AI brain.

WHAT IT ADDS
- Real AI conversation through the OpenAI Responses API.
- Server-side API key protection: the key is never placed in the browser JavaScript.
- Conversation history stored locally in the browser and sent as recent context.
- Optional web search for questions that clearly need current information (latest, today, current, news, weather, prices, scores, etc.).
- DSPARK memory retained locally.
- Voice input -> AI brain -> spoken response.
- Text input -> AI brain -> spoken response.
- Existing YouTube action and quick buttons remain.
- No redesign of the JV3/JV4 layout.

SETUP (COMPUTER)
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Set your API key as an environment variable:
   Windows PowerShell: $env:OPENAI_API_KEY="your_key"
   macOS/Linux: export OPENAI_API_KEY="your_key"
4. Optional: set OPENAI_MODEL (default: gpt-5-mini).
5. Run: node server.js
6. Open: http://localhost:3000

IMPORTANT
Do not paste an OpenAI API key into index.html or app.js. Keep it on the server.
The AI API may incur usage charges according to the API account's current pricing.

ANDROID
A normal file:// opening of index.html will not have the /api/chat server behind it, so the real AI brain will not work that way. The same project can be hosted on a server or packaged with a local backend for Android in the next build.
