# JARVIS 8 — Android Iron Man Voice Assistant

This version is designed around the requested experience: **say “Hey JARVIS” without opening the app** after the one-time Android permission/setup.

## What is included
- Offline Vosk speech recognition (no Android SpeechRecognizer popup).
- Bundled small English Vosk model through Maven, so GitHub builds do not require a manual model download.
- Persistent microphone foreground service.
- Wake phrase detection for **Hey JARVIS** while the JARVIS screen is closed.
- 9-second command window after “Hey JARVIS”.
- Spoken “Yes, Sir?” acknowledgement.
- TTS pauses microphone capture to reduce JARVIS hearing his own voice.
- Service is not stopped when the JARVIS task is swiped away.
- Battery-optimization exemption request to improve survival on aggressive Android/OEM battery managers.
- GitHub Actions configured for Java 17, Gradle 8.7, Android SDK 35, and APK verification.

## Important Android limitation
Android requires the user to grant microphone permission and start a microphone foreground service while the app is visible. Therefore, **the first launch/setup must happen once**. After that, you can close/swipe away the JARVIS UI and say “Hey JARVIS”.

After a full phone reboot, Android/OEM restrictions can prevent an app from starting a microphone foreground service automatically. If the phone has rebooted, open JARVIS once to re-enable the background microphone service. This is an Android security restriction, not a GitHub/build problem.

On TECNO/HiOS and other aggressive battery managers, allow JARVIS to run in the background / disable battery optimization for JARVIS when Android offers that option.

## AI brain
The wake word and speech recognition are local and do not need an AI server. The existing cloud-brain interface remains separate because an OpenAI API key must never be embedded in an APK. The Android UI can call a secure HTTPS JARVIS server when `SERVER` is configured in `MainActivity.java`.

Without that server, JARVIS can still wake and handle the built-in offline voice responses, but general AI conversations while the UI is closed need the secure server connection.

## GitHub build
1. Put the **`jarvis_android` folder at the repository root**.
2. Open GitHub → **Actions**.
3. Choose **Build JARVIS APK**.
4. Press **Run workflow**.
5. Wait for the green check.
6. Open the run → **Artifacts** → **JARVIS-debug-apk**.
7. Install `app-debug.apk`.
8. Allow microphone permission.
9. Leave JARVIS running once while Android starts the foreground voice service.
10. You can then close the JARVIS screen and say **Hey JARVIS**.

## Build verification
The workflow builds from the correct `jarvis_android` directory, uses Java 17 and Gradle 8.7, installs Android SDK 35/build-tools 35.0.0, and fails the workflow if the APK file is missing.

Vosk is an Apache-licensed offline speech-recognition toolkit; its official model list describes the small English model as suitable for mobile use.


## JARVIS 8.1 voice fixes
- Added the Vosk Android engine and bundled small English model as Gradle dependencies.
- The on-screen microphone button now arms the offline recognizer for one command even while wake-word listening is active.
- Wake word remains `Hey JARVIS`.
- Startup voice: “Good evening, sir. JARVIS is online and ready.”
- Standby voice: “Understood, sir. Entering standby mode.”
- `stop listening` disables wake listening; `go to sleep`/`standby` keeps wake-word detection available.
