const mic=document.getElementById("mic");
const stop=document.getElementById("stop");
const reply=document.getElementById("reply");
const state=document.getElementById("state");
const log=document.getElementById("log");
const message=document.getElementById("message");
const send=document.getElementById("send");
const NATIVE=window.AndroidJarvis||null;
const SERVER_BASE=NATIVE?NATIVE.getServer():"";

const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
const MEMORY_KEY="jarvis_memory_v4_fixed";
const CHAT_KEY="jarvis_chat_v4_fixed";
let recognition=null;
let listening=false;
let stoppingManually=false;
let speaking=false;

function getMemory(){try{return JSON.parse(localStorage.getItem(MEMORY_KEY)||"{}")}catch(e){return {}}}
function setMemory(m){localStorage.setItem(MEMORY_KEY,JSON.stringify(m))}
function getChat(){try{return JSON.parse(localStorage.getItem(CHAT_KEY)||"[]")}catch(e){return []}}
function setChat(c){localStorage.setItem(CHAT_KEY,JSON.stringify(c.slice(-16)))}
function logIt(who,text){
  const d=document.createElement("div"); d.className="entry";
  d.textContent=`${who} — ${text}`; log.appendChild(d); log.scrollTop=log.scrollHeight;
}
function setState(s){state.textContent=s}
function speak(text){
  if(NATIVE){ NATIVE.speak(text); setState("SPEAKING"); return; }
  if(!window.speechSynthesis)return;
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text); u.rate=.98; u.pitch=.9;
  u.onstart=()=>{speaking=true;setState("SPEAKING")};
  u.onend=()=>{speaking=false;setState("READY")};
  u.onerror=()=>{speaking=false;setState("READY")};
  speechSynthesis.speak(u);
}
function normalizeBrand(text){return text.replace(/\b(d[\s-]?spark|dee[\s-]?spark|de[\s-]?spark|ds[\s-]?park|the[\s-]?spark|this[\s-]?park|this[\s-]?spak)\b/gi,"DSPARK").replace(/\s+/g," ").trim()}
function clean(text){return normalizeBrand(text).replace(/[“”"]/g,"").trim()}
function looksLikeBrandStatement(q){return q.includes("dspark") && (q.includes("my brand")||q.includes("clothing brand")||q.includes("brand name")) && (q.includes("remember")||q.includes("save")||q.includes(" is ")||q.includes("called")||q.includes("name is"))}
function looksLikeBrandQuestion(q){return /what('?s| is) (my|the name of my) (clothing )?brand|name of my brand|my brand name|tell me my brand/.test(q)}
function localAnswer(raw){
  const cmd=clean(raw), q=cmd.toLowerCase(), memory=getMemory();
  if(looksLikeBrandStatement(q)){memory.brand="DSPARK";setMemory(memory);return "Understood. I've saved your clothing brand as DSPARK."}
  if(looksLikeBrandQuestion(q)) return memory.brand ? `Your clothing brand is ${memory.brand}.` : "I don't have your clothing brand saved yet. Tell me what your brand is.";
  if(q.includes("open youtube")){window.open("https://www.youtube.com","_blank");return "Opening YouTube."}
  if(q.includes("what can you do")) return "I can think, answer questions, remember information, use voice, speak responses, and help you control supported browser actions.";
  return null;
}
async function askBrain(raw){
  const text=clean(raw);
  const local=localAnswer(text);
  if(local)return local;
  const memory=getMemory();
  const chat=getChat();
  const context = memory.brand ? `User memory: clothing brand = ${memory.brand}.` : "No extra user memory saved.";
  const messages=[...chat,{role:"user",content:`${context}\nUser: ${text}`}];
  setState("THINKING");
  try{
    const r=await fetch((SERVER_BASE||"")+"/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages})});
    const data=await r.json();
    if(!r.ok) throw new Error(data.error||"AI brain unavailable");
    const answer=String(data.answer||"").trim();
    if(!answer)throw new Error("The AI brain returned an empty response.");
    setChat([...chat,{role:"user",content:text},{role:"assistant",content:answer}]);
    return answer;
  }catch(e){
    logIt("ERROR",e.message);
    return "My AI brain is not connected yet. Start the JARVIS server with an OpenAI API key, then try again.";
  }finally{if(!listening&&!speaking)setState("READY")}
}
async function answer(raw){
  const cmd=clean(raw); if(!cmd)return;
  reply.textContent="Thinking..."; setState("THINKING");
  const a=await askBrain(cmd);
  reply.textContent=a; logIt("JARVIS",a); speak(a);
  if(!speaking&&!listening)setState("READY");
}
function start(){
  if(NATIVE){ if(NATIVE.hasMicrophonePermission && !NATIVE.hasMicrophonePermission()){ NATIVE.startListening(); return; } NATIVE.startListening(); setState("LISTENING FOR HEY JARVIS"); return; }
  if(!SR){reply.textContent="Voice recognition is not supported here. Try Chrome.";logIt("ERROR","Speech recognition is unavailable");return}
  if(listening)return;
  recognition=new SR(); recognition.lang="en-US"; recognition.interimResults=false; recognition.continuous=false;
  stoppingManually=false; listening=true;
  recognition.onstart=()=>{setState("LISTENING");mic.classList.add("listening");logIt("SYSTEM","Voice input active")};
  recognition.onresult=e=>{const heard=clean(e.results[0][0].transcript);logIt("YOU",heard);answer(heard)};
  recognition.onerror=e=>{
    if(e.error==="aborted"&&stoppingManually)return;
    if(e.error==="not-allowed"||e.error==="service-not-allowed")reply.textContent="Microphone access is blocked. Allow microphone permission and try again.";
    else if(e.error==="no-speech")reply.textContent="I didn't hear anything. Tap to speak and try again.";
    else reply.textContent="Voice error: "+e.error;
    logIt("ERROR",e.error);
  };
  recognition.onend=()=>{listening=false;mic.classList.remove("listening");recognition=null;if(!speaking&&state.textContent!=="THINKING")setState("READY")};
  try{recognition.start()}catch(e){listening=false;recognition=null;mic.classList.remove("listening");setState("READY");logIt("ERROR","Could not start voice input")}
}
window.jarvisNativeTranscript=function(heard){ heard=clean(heard); if(!heard)return; logIt("YOU",heard); answer(heard); };

window.jarvisNativeState=function(s){
  setState(s);
  if(s==="LISTENING" || s==="LISTENING FOR COMMAND" || s==="AWAITING COMMAND") mic.classList.add("listening");
  else mic.classList.remove("listening");
};
window.jarvisPermissionGranted=function(){
  setState("READY");
  reply.textContent="Microphone access granted. Tap the microphone or say “Hey JARVIS”, Sir.";
  logIt("SYSTEM","Microphone permission granted");
};
window.jarvisPermissionDenied=function(){
  setState("MIC PERMISSION NEEDED");
  reply.textContent="Microphone permission is required for voice input. Allow it in Android Settings, then return to JARVIS.";
  logIt("ERROR","Microphone permission denied");
};
window.jarvisNativeError=function(msg){
  setState("READY");
  logIt("ERROR",msg);
};

mic.onclick=start;
stop.onclick=()=>{if(NATIVE){NATIVE.stopListening();setState("READY");return;} stoppingManually=true;if(recognition){try{recognition.stop()}catch(e){}}if(window.speechSynthesis)speechSynthesis.cancel();listening=false;speaking=false;setState("READY");mic.classList.remove("listening")};

document.querySelectorAll(".quick button").forEach(b=>b.onclick=()=>{logIt("YOU",b.dataset.cmd);answer(b.dataset.cmd)});
function sendMessage(){const text=message.value.trim();if(!text)return;logIt("YOU",text);message.value="";answer(text)}
send.onclick=sendMessage;
message.addEventListener("keydown",e=>{if(e.key==="Enter")sendMessage()});

// Restore the saved DSPARK memory into the browser assistant without changing the UI.
const m=getMemory(); if(!m.brand){m.brand="DSPARK";setMemory(m)}
fetch((SERVER_BASE||"")+"/api/status").then(r=>r.json()).then(s=>{logIt("SYSTEM",s.brain?`AI brain online — ${s.model}`:"AI brain awaiting server API key");}).catch(()=>logIt("SYSTEM","Local mode — start the JARVIS server to connect the AI brain."));
