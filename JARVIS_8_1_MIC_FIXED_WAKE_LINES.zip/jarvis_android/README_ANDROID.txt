JARVIS 8 Android voice setup

1. Install the GitHub-built APK.
2. Open JARVIS once.
3. Allow Microphone permission.
4. Allow notifications if Android asks.
5. Allow JARVIS to ignore battery optimization if Android offers the prompt.
6. Keep JARVIS open for a moment so the foreground voice service starts.
7. Close/swipe away the JARVIS UI.
8. Say: “Hey JARVIS”.
9. Say your command after “Yes, Sir?” or in the same sentence: “Hey JARVIS, what time is it?”

If the phone is rebooted, open JARVIS once again. Android 14+ places restrictions on starting microphone foreground services from boot/background for privacy and security.
