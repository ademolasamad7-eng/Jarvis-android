const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-5-mini';
const ROOT = __dirname;

const SYSTEM_PROMPT = `You are JARVIS, a personal AI assistant inspired by a futuristic Iron Man-style computer assistant. You are assisting the user directly and should sound intelligent, calm, concise, confident, and helpful. Address the user as Sir when it fits naturally, but do not overuse it.

Core abilities:
- Answer general questions and explain things clearly.
- Reason through problems and help plan tasks.
- Remember user-provided preferences and facts when they are supplied in the conversation.
- Help with DSPARK, the user's clothing brand, when relevant.
- When current information is needed, use web search if available rather than pretending to know live facts.
- Never claim you performed an action unless the browser actually performed it.
- Keep most spoken responses reasonably concise, because your response may be read aloud.

Known memory:
The user's clothing brand is DSPARK. Treat this as a user-provided memory, but allow the user to change it.
`;

function sendJson(res, status, data) {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store'});
  res.end(JSON.stringify(data));
}

function sendFile(res, file) {
  const ext = path.extname(file).toLowerCase();
  const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.txt':'text/plain; charset=utf-8'};
  try {
    const data = fs.readFileSync(file);
    res.writeHead(200, {'Content-Type': types[ext] || 'application/octet-stream'});
    res.end(data);
  } catch { res.writeHead(404); res.end('Not found'); }
}

async function askOpenAI(messages, useWeb) {
  if (!API_KEY) throw new Error('OPENAI_API_KEY is not configured on the Jarvis server.');
  const body = {
    model: MODEL,
    instructions: SYSTEM_PROMPT,
    input: messages,
    max_output_tokens: 700
  };
  if (useWeb) body.tools = [{type:'web_search'}];

  const r = await fetch('https://api.openai.com/v1/responses', {
    method:'POST',
    headers:{'Content-Type':'application/json','Authorization':`Bearer ${API_KEY}`},
    body:JSON.stringify(body)
  });
  const text = await r.text();
  if (!r.ok) throw new Error(`AI API ${r.status}: ${text.slice(0,500)}`);
  const data = JSON.parse(text);
  const output = (data.output || []).flatMap(item => item.content || [])
    .filter(c => c.type === 'output_text' && typeof c.text === 'string')
    .map(c => c.text).join('\n').trim();
  return output || 'I completed the reasoning, but no spoken response was returned.';
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'POST' && req.url === '/api/chat') {
    let raw='';
    req.on('data', c => { raw += c; if (raw.length > 200000) req.destroy(); });
    req.on('end', async () => {
      try {
        const payload = JSON.parse(raw || '{}');
        const messages = Array.isArray(payload.messages) ? payload.messages : [];
        if (!messages.length) return sendJson(res, 400, {error:'No messages supplied.'});
        const trimmed = messages.slice(-16).map(m => ({
          role: m.role === 'assistant' ? 'assistant' : 'user',
          content: String(m.content || '').slice(0,5000)
        }));
        const latest = trimmed[trimmed.length-1]?.content || '';
        const useWeb = /\b(search|look up|latest|today|current|news|weather|price|score|recent)\b/i.test(latest);
        const answer = await askOpenAI(trimmed, useWeb);
        sendJson(res, 200, {answer, model:MODEL, web:useWeb});
      } catch (e) {
        sendJson(res, 500, {error:e.message || 'Unknown server error'});
      }
    });
    return;
  }

  if (req.method === 'GET' && req.url === '/api/status') {
    return sendJson(res, 200, {online:true, brain:Boolean(API_KEY), model:MODEL});
  }

  let requested = req.url.split('?')[0];
  if (requested === '/') requested = '/index.html';
  const safe = path.normalize(requested).replace(/^([.][.][\\/])+/, '');
  sendFile(res, path.join(ROOT, safe));
});

server.listen(PORT, () => {
  console.log(`JARVIS running at http://localhost:${PORT}`);
  console.log(`AI brain: ${API_KEY ? 'configured' : 'NOT configured'}`);
  console.log(`Model: ${MODEL}`);
});
